package cp2022.solution;
import cp2022.base.Workplace;
import cp2022.base.WorkplaceId;
import cp2022.base.Workshop;

import java.util.*;
import java.util.concurrent.*;

public class Solution implements Workshop {
    private final ConcurrentHashMap<WorkplaceId, Boolean> isOccupied = new ConcurrentHashMap<>();
    private final Semaphore cycleSemaphore = new Semaphore(0);
    private final ConcurrentHashMap<Long, Semaphore> ownSemaphore = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<WorkplaceId, MyWorkplace> workplaces = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<Long, WorkplaceId> occupiedWorkplace = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<WorkplaceId, Long> whoOccupiedWorkplace = new ConcurrentHashMap<>();
    private volatile int howManyLeft = 0;
    private final Semaphore semaphoreForEnter;
    private final ConcurrentHashMap<Long, WorkplaceId> preferences = new ConcurrentHashMap<>();
    private static volatile List<Long> valueOfCycle = new ArrayList<>();
    private volatile CyclicBarrier barrier;
    private final Semaphore mutex = new Semaphore(1);
    public Solution(Collection<Workplace> workplaces) {
        for (Workplace w: workplaces) {
            MyWorkplace workplace = new MyWorkplace(w);
            this.workplaces.put(w.getId(), workplace);
            isOccupied.put(w.getId(), false);
        }
        semaphoreForEnter = new Semaphore(2 * workplaces.size());
    }
    private boolean isCycle(long start, long curenntlyThread) {
        WorkplaceId currentlyPosition;
        long currentlyId = start;
        while (curenntlyThread != currentlyId ) {
            if (preferences.get(currentlyId) == null) {
                return false;
            }
            currentlyPosition = preferences.get(currentlyId);

            if (whoOccupiedWorkplace.get(currentlyPosition) == null) {
                return false;
            }
            currentlyId = whoOccupiedWorkplace.get(currentlyPosition);
        }
        return true;
    }
    private int cycleLength(long start, long curenntlyThread) {
        int length = 1;
        WorkplaceId curenntlyPosition;
        long curenntlyId = start;
        while (curenntlyThread != curenntlyId) {
            valueOfCycle.add(curenntlyId);
            curenntlyPosition = preferences.get(curenntlyId);
            length++;
            curenntlyId = whoOccupiedWorkplace.get(curenntlyPosition);
        }
        this.barrier = new CyclicBarrier(length, Solution::clear);
        return length;
    }
    private static void clear() {
        valueOfCycle.clear();
        valueOfCycle = new ArrayList<>();
    }
    @Override
    public Workplace enter(WorkplaceId wid) {
        try {
            semaphoreForEnter.acquire();
            mutex.acquire();
            long currentlyThreadId = Thread.currentThread().getId();
            if (isOccupied.get(wid)) {
                workplaces.get(wid).addValue(currentlyThreadId);
                preferences.put(currentlyThreadId,wid);
                ownSemaphore.put(currentlyThreadId, new Semaphore(1));
                ownSemaphore.get(currentlyThreadId).acquire();
                mutex.release();
                ownSemaphore.get(currentlyThreadId).acquire();
                workplaces.get(wid).remove(currentlyThreadId);
                preferences.remove(currentlyThreadId);
            }
            isOccupied.compute(wid, (key, val)->true);
            occupiedWorkplace.put(currentlyThreadId, wid);
            whoOccupiedWorkplace.put(wid, currentlyThreadId);
            mutex.release();
            return workplaces.get(wid);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    private void updateData(WorkplaceId wid, long curenntlyThreadId) {
        WorkplaceId workplace = occupiedWorkplace.get(curenntlyThreadId);
        occupiedWorkplace.remove(curenntlyThreadId);
        occupiedWorkplace.put(curenntlyThreadId, wid);

        whoOccupiedWorkplace.remove(workplace, curenntlyThreadId);
        whoOccupiedWorkplace.put(wid, curenntlyThreadId);

    }
    private Workplace emptyWorkplace(WorkplaceId wid) {
        long curenntlyThreadId = Thread.currentThread().getId();
        WorkplaceId workplace = occupiedWorkplace.get(curenntlyThreadId);
        isOccupied.compute(wid, (key, val) -> true);
        updateData(wid,curenntlyThreadId);
        preferences.remove(curenntlyThreadId);
        if (workplaces.get(workplace).isEmpty()) {
            isOccupied.compute(workplace, (key, val) -> false);
            mutex.release();
        } else {
            long candidateId = workplaces.get(workplace).first();
            CountDownLatch latch = new CountDownLatch(2);
            workplaces.get(wid).setLeavingLatch(latch);
            workplaces.get(workplace).setEnteringLantch(latch);
            ownSemaphore.get(candidateId).release();
        }
        return workplaces.get(wid);
    }
    private Workplace cycle(WorkplaceId wid) {
        long curenntlyTreadId = Thread.currentThread().getId();
        long threadId = whoOccupiedWorkplace.get(wid);
        int length = cycleLength(threadId, curenntlyTreadId);
        CountDownLatch latch = new CountDownLatch(length);
        workplaces.get(wid).setEnteringLantch(latch);
        workplaces.get(wid).setLeavingLatch(null);

        //budze wszytskie watki naraz, nie wiem czy dobrze
        // dodac mutex gdzies
        for (long value : valueOfCycle) {
            WorkplaceId preference = preferences.get(value);
            workplaces.get(preference).setEnteringLantch(latch);
            workplaces.get(preference).setLeavingLatch(null);
            ownSemaphore.get(value).release();
            try{
            cycleSemaphore.acquire();}
            catch (InterruptedException e){
                throw new RuntimeException(e);
                //panic:Interupted -> w tresci

            }
        }

        updateData(wid,curenntlyTreadId);

        preferences.remove(curenntlyTreadId);
        workplaces.get(wid).remove(curenntlyTreadId);

        try {
            barrier.await();
        } catch (InterruptedException | BrokenBarrierException e) {
            throw new RuntimeException(e);
        }
        mutex.release();
        return workplaces.get(wid);
    }
    private Workplace includeInCycle(WorkplaceId wid) {
        //try {
         //   mutex.acquire();
        //} catch (InterruptedException e) {
        //    throw new RuntimeException(e);
       // }
        long curenntlyThreadId = Thread.currentThread().getId();
        updateData(wid, curenntlyThreadId);
        try {
           // mutex.release();
            cycleSemaphore.release();
            barrier.await();
        } catch (InterruptedException | BrokenBarrierException e) {
            throw new RuntimeException(e);
        }
       // mutex.release();
        return workplaces.get(wid);
    }
    @Override
    public Workplace switchTo(WorkplaceId wid) {
        try {
            mutex.acquire();
            if (isOccupied.get(wid)) {
                long currentlyThreadId = Thread.currentThread().getId();
                workplaces.get(wid).addValue(currentlyThreadId);
                preferences.put(currentlyThreadId,wid);
                long threadId = whoOccupiedWorkplace.get(wid);
                if (isCycle(threadId, currentlyThreadId)) {
                    return cycle(wid);
                } else {
                    ownSemaphore.put(currentlyThreadId , new Semaphore(1));
                    ownSemaphore.get(currentlyThreadId).acquire();
                    mutex.release();
                    ownSemaphore.get(currentlyThreadId).acquire();
                    preferences.remove(currentlyThreadId);
                    workplaces.get(wid).remove(currentlyThreadId);
                    if (valueOfCycle.contains(currentlyThreadId)) {
                        return includeInCycle(wid);
                    }
                }
            }
            return emptyWorkplace(wid);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void leave() {
        try {
            mutex.acquire();
            long curenntlyThreadId = Thread.currentThread().getId();
            WorkplaceId occupiedWorkplace = this.occupiedWorkplace.get(curenntlyThreadId);
            whoOccupiedWorkplace.remove(occupiedWorkplace,curenntlyThreadId);
            this.occupiedWorkplace.remove(curenntlyThreadId);
            howManyLeft++;

            if (howManyLeft == 2 * workplaces.size()) {
                for (int i = 0; i < 2 * workplaces.size(); i++) {
                    semaphoreForEnter.release();
                }
                howManyLeft = 0;
            }

            if (workplaces.get(occupiedWorkplace).isEmpty()) {
                isOccupied.compute(occupiedWorkplace, (key, val) -> false);
                mutex.release();
            } else {
                long candidateId = workplaces.get(occupiedWorkplace).first();
                ownSemaphore.get(candidateId).release();
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
