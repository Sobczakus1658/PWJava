package cp2022.solution;

import cp2022.base.Workplace;
import java.util.concurrent.CountDownLatch;
import java.util.LinkedList;
public class MyWorkplace extends Workplace {
    private final Workplace workplace;
    private CountDownLatch enteringLatch = null;
    private CountDownLatch leavingLatch = null;
    private final LinkedList<Long> waitingThreads;
    public MyWorkplace(Workplace workplace) {
        super(workplace.getId());
        this.workplace = workplace;
        waitingThreads = new LinkedList<>();
    }
    @Override
    public void use() {
        beforeUse();
        workplace.use();
    }
    public void setLeavingLatch(CountDownLatch latch){
        leavingLatch = latch;
    }
    public void setEnteringLantch(CountDownLatch latch){
        enteringLatch = latch;
    }
    public void beforeUse() {
        if (enteringLatch != null) {
            enteringLatch.countDown();
            try {
                enteringLatch.await();
            }
            catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        if (leavingLatch != null) {
            leavingLatch.countDown();
        }
    }
    public void remove(long toRemove) {
        waitingThreads.remove(toRemove);
    }
    public boolean isEmpty() {
        return waitingThreads.isEmpty();
    }
    public long first(){
        return waitingThreads.get(0);
    }
    public void addValue(long wartosc){
        waitingThreads.add(wartosc);
    }
}
