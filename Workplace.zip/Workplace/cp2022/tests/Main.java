package cp2022.tests;

public class Main {
    public static void main(String[] args) {
        for( int i = 0 ; i < 100; i++) {
            cp2022.tests.pggp_tests.Main.main(args);
            cp2022.tests.kwasow.KwasowMain.main(args);
            cp2022.tests.fibonacci.Main.main(args);
        }
    }
}
