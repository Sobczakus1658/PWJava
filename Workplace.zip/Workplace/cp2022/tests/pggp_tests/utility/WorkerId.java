package cp2022.tests.pggp_tests.utility;

public class WorkerId {
    public final int id;

    public WorkerId (int id) {
        this.id = id;
    }
}
